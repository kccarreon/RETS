<?php namespace PHRETS\Exceptions;

class InvalidConfiguration extends \Exception
{

}
