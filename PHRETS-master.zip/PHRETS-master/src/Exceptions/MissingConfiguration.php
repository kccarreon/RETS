<?php namespace PHRETS\Exceptions;

class MissingConfiguration extends \Exception
{

}
