<?php namespace PHRETS\Exceptions;

class RETSException extends \Exception
{

}
