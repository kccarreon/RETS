<?php

require_once(__DIR__ . "/../vendor/autoload.php");
require_once(__DIR__ . "/Integration/BaseIntegration.php");
require_once(__DIR__ . "/Integration/Parsers/CustomSystemParser.php");
require_once(__DIR__ . "/Integration/Parsers/CustomXMLParser.php");
